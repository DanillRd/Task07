<template>
    <div class="form-container">
        <button @click="toggleForm">Toggle Form</button>
        <form v-if="showForm" @submit.prevent="submitForm" class="login-form">
            <div>
                <label for="name">Name:</label>
                <input type="text" id="name" v-model="formData.name" required />
                <div v-if="formErrors.name" class="error">{{ formErrors.name }}</div>
            </div>
            <div>
                <label for="age">Age:</label>
                <input type="number" id="age" v-model="formData.age" required />
                <div v-if="formErrors.age" class="error">{{ formErrors.age }}</div>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" v-model="formData.email" required />
                <div v-if="formErrors.email" class="error">{{ formErrors.email }}</div>
            </div>
            <button type="submit">Submit</button>
        </form>
    </div>
</template>

<script>
import { ref } from 'vue';
import { saveDataToIndexedDB } from '/src/components/indexeddb';
import { useRouter } from 'vue-router';

export default {
    setup() {
        const showForm = ref(true);
        const formData = ref({
            name: '',
            age: '',
            email: '',
        });

        const formErrors = ref({
            name: '',
            age: '',
            email: '',
        });

        const router = useRouter();

        const toggleForm = () => {
            if (showForm.value) {
                formData.value = {
                    name: '',
                    age: '',
                    email: '',
                };
                formErrors.value = {
                    name: '',
                    age: '',
                    email: '',
                };
            }
            showForm.value = !showForm.value;
        };

        const submitForm = () => {
            formErrors.value = {};

            if (!formData.value.name) {
                formErrors.value.name = 'Name is required.';
            }

            if (!formData.value.age) {
                formErrors.value.age = 'Age is required.';
            } else if (isNaN(formData.value.age) || formData.value.age <= 0) {
                formErrors.value.age = 'Invalid age.';
            }

            if (!formData.value.email) {
                formErrors.value.email = 'Email is required.';
            } else if (!validateEmail(formData.value.email)) {
                formErrors.value.email = 'Invalid email format.';
            }

            saveDataToIndexedDB(formData.value)
                .then(() => {
                    console.log('Data successfully saved to IndexedDB:', formData.value);
                    router.push('/MoviePage'); // Используйте правильный путь к компоненту MoviePage
                })
                .catch((error) => {
                    console.error('Error saving data to IndexedDB:', error);
                });
        };

        const validateEmail = (email) => {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailPattern.test(email);
        };

        return {
            showForm,
            formData,
            formErrors,
            toggleForm,
            submitForm,
        };
    },
};
</script>


<style>
.form-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.login-form {
    max-width: 400px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
}

.error {
    color: red;
    font-size: 12px;
    margin-top: 5px;
}
</style>










