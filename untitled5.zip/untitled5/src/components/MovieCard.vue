<template>
    <div class="movie-card">
        <h2>{{ movie.title }}</h2>
        <p>Release Date: {{ movie.release_date }}</p>
        <p>Popularity: {{ movie.popularity }}</p>
        <!-- Добавьте другие поля, которые вы хотите отобразить о фильме -->
    </div>
</template>

<script>
export default {
    props: {
        movie: Object, // Принимаем объект фильма в качестве свойства из родительского компонента
    },
};
</script>

<style>
/* Стили для карточки фильма */
.movie-card {
    background-color: #f0f0f0;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
</style>
