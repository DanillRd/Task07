/* */<template>
    <header>
        <h1>My Task App Header </h1>
    </header>
</template>

<style>
header {
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    background-color: #007bff;
    color: #fff;
    padding: 20px;
    text-align: center;
}
</style>