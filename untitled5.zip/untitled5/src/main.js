import { createApp } from 'vue';
import App from './App.vue';
import { createRouter, createWebHistory } from 'vue-router';
import LoginPage from './components/LoginForm.vue';
import MoviePage from './MoviePage.vue'; // Обновленный путь для MoviePage.vue

const routes = [
    { path: '/', component: LoginPage },
    { path: '/movie', component: MoviePage },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

const app = createApp(App);
app.use(router);
app.mount('#app');




