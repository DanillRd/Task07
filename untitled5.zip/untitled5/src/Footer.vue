<template>
    <footer class="footer">
        <!-- Your footer content goes here -->
        <p>&copy; 2023 Your Website. All rights reserved.</p>
    </footer>
</template>

<style>
footer {
    background-color: #f0f0f0;
    padding: 10px;
    text-align: center;
    position: sticky;
    bottom: 0;
    width: 100%;
}
</style>
