<template>
    <div class="form">
        <!-- форма здесь -->
        <div class="cards">
            <Card v-for="card in cards" :key="card.id" :data="card" />
        </div>
    </div>
</template>

<script>
import MovieCard from './components/MovieCard.vue'; // Импортируем компонент MovieCard.vue
import { getCards } from './api.js';

export default {
    components: {
        MovieCard, // Регистрируем компонент MovieCard для использования в шаблоне
    },
    data() {
        return {
            movies: [],
            formData: {
                name: '',
                age: '',
                email: '',
            },
        };
    },
    created() {
        this.loadMovies();
    },
    methods: {
        async loadMovies() {
            try {
                const data = await getCards();
                this.movies = data;
            } catch (error) {
                console.error(error);
                this.movies = [];
            }
        },
        submitForm() {
            // Handle form submission logic here
            // You can add API calls or other actions based on the form data
            // For this example, we are not handling the form submission logic
        },
    },
};
</script>

<style>
/* Add your form and cards styles here */
.form {
    max-width: 600px;
    margin: 0 auto;
}

.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    grid-gap: 20px;
}
</style>




